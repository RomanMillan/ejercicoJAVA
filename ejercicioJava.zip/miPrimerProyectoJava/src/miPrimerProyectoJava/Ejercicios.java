package miPrimerProyectoJava;

import java.util.Scanner;

public class Ejercicios {
	
	static final float PI=(float) 3.14;
	static final int MAXELEMENTOS = 10;
	static final char APODO = 'D';
	static Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float x;
		char num;
		String aux;
		
		x = PI*3;
		
		
		System.out.println("Hola Mundo");
		System.out.println("El valor de x es:" + x +" y se acabo");
		System.out.println("Introduce un numero: ");
		num = teclado.nextLine().charAt(0);
		System.out.println("El número que acabas de introducir es: " + num);
		aux = teclado.nextLine();
		System.out.println(aux);
	}

}
