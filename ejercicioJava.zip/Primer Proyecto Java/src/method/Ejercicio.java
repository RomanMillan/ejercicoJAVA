package method;


public class Ejercicio {
	
	public static final Double PI = 3.14;
	

	public static void main(String[] args) {
				
		// Variables
		
		// Inicio
		System.out.println(numeroSolucionesEcuacionSegundoGrado(2,1,3));
				
				
	}
	
	public static int numeroSolucionesEcuacionSegundoGrado(int a, int b, int c) {
		int resul;
		resul = b*b -4*a*c;
		if (resul ==0) {
			return 1;
		}else if (a ==0) {
			return -1;
		}else if (resul <0) {
			return 0;
		}else {
			return 2;
		}
	}
	
	public static Double solucionSumaEcuacionSegundoGrado(int a, int b, int c) {
		int numSoluciones = numeroSolucionesEcuacionSegundoGrado (a, b, c);
		if (numSoluciones == -1 || numSoluciones == 0){
			return (double) -1000;
		}else if (numSoluciones == 1){
			return (double) -b/(2*a);
		}else{
			return (double) (-b+Math.sqrt(b*b-4*a*c))/(2*a);
		}
	}
	
	
	public static Double solucionRestaEcuacionSegundoGrado(int a, int b, int c) {
		
	}	
	
	public static Double areaCirculo(Double r) {
		Double a;
		a = PI * Math.pow(r, 2);
		return a;
	}
	
	public static Double longitudCirculo(Double r) {
		double L;
		L = 2* PI * r;
		return L;
	}
	
	public static boolean esMultiplo(int a, int b) {
		int respuesta;
		if (b==0 || a ==0) {
			return false;
		}
		respuesta = a%b;
		if (respuesta==0) {
			return true;
		}else {
			return false;
		}
	}
	
	public static int horaMayor(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
		if (hora1 > hora2 && min1 > min2 && seg1 > seg2){
			return 1;
		}else if (hora1 > hora2 && min1 > min2 && seg1 < seg2){
			return 1;
		}else if (hora1 > hora2 && min1 < min2 && seg1 < seg2){
			return 1;
		}else if (hora1 < hora2 && min1 < min2 && seg1 < seg2) {
			return 2;
		}else if (hora1 < hora2 && min1 < min2 && seg1 > seg2) {
			return 2;
		}else if (hora1 < hora2 && min1 > min2 && seg1 > seg2) {
			return 2;
		}else if (hora1 == hora2 && min1 == min2 && seg1 == seg2){
			return 0;
		}else {
			return -1000;
		}
	}
	
	public static int segundosEntre(int hora1, int min1, int seg1, int hora2, int min2, int seg2) {
		
		
	}
	
	public static int maximoComunDivisor(int a, int b) {
		
	}
	
	public static int minimoComunMultiplo(int a, int b) {
		
	}
	
	public static String binario(int num) {
		
	}
	
	public static int decimal(String num) {
		
	}
}
